"""Observe exact existing results; never changes them or their time budgets."""
import json,os,time
from pathlib import Path

def pytest_configure(config):
 from llmloop.typed_bv_cfg import TypedBVScalarCFG
 original=TypedBVScalarCFG.division_induction
 def observed(self,*args,**kwargs):
  result=original(self,*args,**kwargs)
  path=Path(os.environ['LLMLOOP_PROOF_DUMP_DIR']);path.mkdir(exist_ok=True)
  (path/(str(time.time_ns())+'.json')).write_text(json.dumps({'nodeid':os.getenv('PYTEST_CURRENT_TEST'),'proof':result},indent=2)+'\n')
  return result
 TypedBVScalarCFG.division_induction=observed
