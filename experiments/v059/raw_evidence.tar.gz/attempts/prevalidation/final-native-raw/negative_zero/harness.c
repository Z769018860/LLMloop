#include <stdio.h>
long f(int);int main(void){printf("%lld\n",(long long)f(-5));printf("%lld\n",(long long)f(-1));printf("%lld\n",(long long)f(0));return 0;}
