#include <stdio.h>
long f(int,int);int main(void){printf("%lld\n",(long long)f(0,0));printf("%lld\n",(long long)f(0,3));printf("%lld\n",(long long)f(3,0));printf("%lld\n",(long long)f(3,5));return 0;}
