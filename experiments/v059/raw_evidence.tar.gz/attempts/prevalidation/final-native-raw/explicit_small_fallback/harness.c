#include <stdio.h>
long f(int);int main(void){printf("%lld\n",(long long)f(0));printf("%lld\n",(long long)f(1));printf("%lld\n",(long long)f(2));printf("%lld\n",(long long)f(3));return 0;}
