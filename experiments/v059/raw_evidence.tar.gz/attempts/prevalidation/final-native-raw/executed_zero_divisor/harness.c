#include <stdio.h>
long f(int);int main(void){printf("%lld\n",(long long)f(1));return 0;}
