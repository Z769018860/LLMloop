#include <stdio.h>
long f(int);int main(void){printf("%lld\n",(long long)f(0));printf("%lld\n",(long long)f(1));printf("%lld\n",(long long)f(255));printf("%lld\n",(long long)f(300));return 0;}
