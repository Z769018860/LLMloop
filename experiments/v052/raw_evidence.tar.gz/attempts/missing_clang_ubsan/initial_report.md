# v0.52 experimental continuation (v0.51 proof engine)

Frozen source: `1860477c562a2750ddecd27b122d9135eb7913bb`; tree `1b6d9fb5c289a9a2956cc9f6ee41a26d50af5b03`.

Full regression: **2436 passed, 0 skipped**. All experiment commands run locally, sequentially, with no retries or larger proof-query budgets. No Actions or KLEE.

## Static entry-contract grid

The 384 constructed cases exhaust minima 1..8 × actual capacities 1..8 × `a`, `a+0`, `a+1` × inline/header-linked snapshot routes. Results: `{"insufficient_extent": 112, "proved": 144, "unsupported_interior": 128}`. Independent SMT replays: `{"sat": 240, "unsat": 784}`.

The body intentionally ignores its pointer, so entry definedness cannot rely on body reads. Interior slices remain UNKNOWN even when the remaining extent is sufficient. Their SAT base guards identify an unsupported analysis fragment, not source UB. Invalid static calls are never executed as positive native evidence.

The retained dual-compiler O0/O2 static matrix has 1848 output matches, 308 model checks, 12 arithmetic traps, and 6 memory failures. Sanitizer-silent invalid calls stay excluded from positive correspondence.

## Finite heap versus owned-list induction

Two unchanged, constructed existing list examples (sum and ordered stateful prefix fold) are analyzed from the same C source under `calls` and `list_calls`. Allocation failure remains enabled. This compares different backend contracts; it is **not** a LoopSCC on/off ablation.

Each point has three fresh-process repetitions in one predetermined shuffled order. Default proof limits are unchanged; 60 seconds is the external process ceiling. Times include Clang ingestion/normalization. These descriptive measurements are not CPU-pinned, cross-machine results or a universal speedup claim.

| Case | n | Finite heap | Median seconds | List induction | Median seconds |
| --- | ---: | --- | ---: | --- | ---: |

Fresh process outcomes: `{}`. Both summary proofs additionally cover the full declared interval n=0..1,000,000, with every allocation-failure prefix, and None exact arithmetic audits replay independently.

GCC/Clang, O0/O2, original/normalized/composed programs match None independent outputs and None model evaluations. Native instrumentation checks every payload and free identity, allocation attempts, successful allocation count and zero remaining live nodes. The Python formula is cross-checked by an independent short-list walk. Million-node cases include empty, early-failure, half-built and complete chains. An incorrect supplied fold is rejected, and an overflowing int fold is rejected with four required native UBSan failures.

## Retained upstream functions and limits

The pinned original compiler-rt popcount and unsigned-division scripts are rerun, retaining independent functional, source-safety and negative-control outcomes in `popcount.json` and `division.json`. Their direct timeouts remain separate from successful compositional/inductive strategies. This refresh does not rerun or claim completion of the whole upstream matrix.

No proof-engine support is added. General VLA and interior slices, arbitrary ownership/heap shapes, wider C/LLVM semantics and arbitrary branch closed-form synthesis remain open. These constructed fixtures do not close representative-library evaluation. Clang and normalization remain trusted; native samples are supplementary evidence.

Source hashes: 409 paths. Historical evidence hashes: 557 paths. Checks: `{"division": false, "full_pytest_count": true, "heap_scaling": false, "heap_scaling_result": false, "historical_evidence_unchanged": true, "popcount": true, "pytest": true, "source_unchanged": true, "static_grid": true, "static_grid_result": true, "static_native": true, "static_native_result": true}`. Passed: **False**.
