# v0.54 scoped local VLAs and initialized-local bounds

Frozen source `431d5f91bbe539c28ae90de622e503d8e616b051`, tree `99ee115879cc51053d5793e250febcb96f6c6926`.
Full regression: **2543 passed, 0 skipped**. There are
63 new tests; three existing refusal cases advance to checked support, and no
existing case is deleted. All validation is local, without Actions, KLEE,
retries or larger query/execution budgets.

## Implemented source contract

The Clang calls bridge and typed CFG heap/call kernels now admit integer VLAs
in explicit nested blocks, structured loop bodies, case blocks and for
initializers. A bound can be one uniquely named visible scalar parameter or
initialized local. Clang declaration identities and normalized source names
are retained; a lexical pass checks declaration order, block visibility and
for scope before call expansion introduces administrative gotos.

Each execution of a declaration captures its then-current typed value and
creates fresh storage/initialization flags. A block-body VLA expires on that
block's exit, including break/continue/return. The same source declaration in
the next iteration cannot revive an old pointer or inherit initialized cells.
A for-initializer VLA instead lives across condition, body and increment, with
one saved extent, until the entire loop exits. Existing call expansion retains
these boundaries when conditions/initializers/increments contain helpers.
Original source goto/labels remain refused.

`memory_model.bounded_local_vla.instances` binds each object name, scope, saved
extent and declaration visit. The guarded negated positivity/capacity queries
retain the same visit index for independent replay. Eight cells per object,
eight cumulative represented instances, 64 cells, existing path/step/call
limits and the 5000 ms per-query cap are unchanged. Expired instances still
count against the representation budget; no unbounded reclamation proof is
claimed. Bound expressions and VLA parameters remain unsupported.

## Independent native and negative controls

Ten positive scoped/loop cases produce **360
native output matches** with GCC/Clang O0/O2 original separate objects,
preprocessed snapshots and normalized C. All 30
model evaluations match separate Python formulas. The cases include changing
loop extents, saved for-initializer size, array shadowing, borrowing while live,
break/continue, helper conditions and helper increments. Query replays:
`{"sat": 2, "unsat": 48}`.

There are 36 required nonpositive-bound and
body-arithmetic traps and 6 specific
bounds failures. Four independent source controls reject prior-iteration
initialization reuse, stale iteration aliases, expired block aliases and
expired for-initializer aliases. Sanitizer detection for those lifetime/
initialization controls is not claimed. Source tests additionally check
lexical invisibility even in unexecuted branches, ambiguous bounds, source
jumps, helper increment arguments after body exit, case scopes, static-entry
lifetime checks and the unchanged finite object frontier.

The retained v0.53 VLA matrix has 768 matches;
static-array and ordinary-array matrices have 1848
and 1632 matches. They retain their arithmetic,
bounds and capacity-frontier controls. The new CLI example returns 30 for n=3
while each iteration has a different saved extent.

## Remaining requirements and evidence

General compound bound expressions, VLA parameters/typedef effects, arbitrary
source goto/labels, multidimensional/pointer-element VLA layouts, static-entry
interior slices, arbitrary heap/ownership contracts, general recurrence
discovery and complete C/LLVM remain open. Compiler ingestion, structural
lowering and typed kernels remain trusted. Finite native samples supplement
source obligations, not a compiler-equivalence theorem.

All 419 source paths and 569 historical evidence paths are
hash checked. Prevalidation records remain under attempts and are not counted
as frozen release acceptance. Checks: `{"array_native": true, "cli_result": true, "full_test_count": false, "historical_evidence_unchanged": true, "pytest": false, "retained_array_result": true, "retained_static_result": true, "retained_vla_result": true, "scoped_cli": true, "scoped_native": true, "scoped_native_result": true, "source_unchanged": true, "static_native": true, "vla_native": true}`.
Passed: **False**.
