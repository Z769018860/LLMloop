#include <stdlib.h>
static int seq[]={-1,4};
static unsigned pos;
int __VERIFIER_nondet_int(void){if(pos>=sizeof(seq)/sizeof(seq[0]))exit(90);return seq[pos++];}
extern int __VERIFIER_nondet_int(void);
int benchmark_main() {
  int a = __VERIFIER_nondet_int();
  int b = __VERIFIER_nondet_int();
  if (!(a >= -4 && a <= 4 && b >= -4 && b <= 4)) return 0;
  int x = 1;
  int y = b;
  int z = a;
  while (y < 1000) {
    z = z + z * 3;
    y = z * 2;
    x = y * 7;
  }
  return 0;
}

int main(void){return benchmark_main();}
