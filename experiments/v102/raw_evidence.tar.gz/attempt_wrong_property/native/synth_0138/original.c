#include <stdlib.h>
static int seq[]={4,4};
static unsigned pos;
int __VERIFIER_nondet_int(void){if(pos>=sizeof(seq)/sizeof(seq[0]))exit(90);return seq[pos++];}
extern int __VERIFIER_nondet_int(void);
int benchmark_main() {
  int a = __VERIFIER_nondet_int();
  int b = __VERIFIER_nondet_int();
  if (!(a >= 0 && a <= 4 && b >= 0 && b <= 4)) return 0;
  int x = 0;
  int y = 2;
  while (y != 100) {
    x = y + x * a;
  }
  return 0;
}

int main(void){return benchmark_main();}
