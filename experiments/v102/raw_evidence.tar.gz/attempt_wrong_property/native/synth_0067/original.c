#include <stdlib.h>
static int seq[]={8,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
static unsigned pos;
int __VERIFIER_nondet_int(void){if(pos>=sizeof(seq)/sizeof(seq[0]))exit(90);return seq[pos++];}
extern int __VERIFIER_nondet_int(void);
int benchmark_main() {
  int a = __VERIFIER_nondet_int();
  if (!(a >= 0 && a <= 8)) return 0;
  int x = 2;
  int y = 2;
  while (y != 100) {
    if (__VERIFIER_nondet_int() != 0) { x = y * 7; } else { x = x * 2; }
  }
  return 0;
}

int main(void){return benchmark_main();}
