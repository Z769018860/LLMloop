#include <stdlib.h>
static int seq[]={12,12,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0};
static unsigned pos;
int __VERIFIER_nondet_int(void){if(pos>=sizeof(seq)/sizeof(seq[0]))exit(90);return seq[pos++];}
extern int __VERIFIER_nondet_int(void);
int benchmark_main() {
  int a = __VERIFIER_nondet_int();
  int b = __VERIFIER_nondet_int();
  if (!(a >= 0 && a <= 12 && b >= 0 && b <= 12)) return 0;
  int x = 2;
  int y = 0;
  while (__VERIFIER_nondet_int() != 0) {
    if (__VERIFIER_nondet_int() != 0) { x = y + x * a; } else { x = y + x * 3; }
  }
  return 0;
}

int main(void){return benchmark_main();}
