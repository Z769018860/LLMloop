#include <stdlib.h>
static int seq[]={4};
static unsigned pos;
int __VERIFIER_nondet_int(void){if(pos>=sizeof(seq)/sizeof(seq[0]))exit(90);return seq[pos++];}
extern int __VERIFIER_nondet_int(void);
int benchmark_main() {
  int a = __VERIFIER_nondet_int();
  if (!(a >= 0 && a <= 4)) return 0;
  int x = a;
  int y = a;
  int z = 2;
  while (z < 1000) {
    y = z + y * 2;
  }
  return 0;
}

int main(void){return benchmark_main();}
