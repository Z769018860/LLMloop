long f(int a,int b){long x=0;for(int i=0;i<b-a;i++){x++;}return x;}
#include <stdio.h>
int main(void){for(int a=-8;a<=8;a++)for(int b=-8;b<=8;b++)printf("%d %d %ld\n",a,b,f(a,b));return 0;}
