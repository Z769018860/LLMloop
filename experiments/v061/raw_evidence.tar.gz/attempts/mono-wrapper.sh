#!/bin/sh
export MONO_PATH=/workspace/scratch/c7749104332a/p0-tools/native/usr/lib/mono/4.5
export MONO_GAC_PREFIX=/workspace/scratch/c7749104332a/p0-tools/native/usr
export LD_LIBRARY_PATH=/workspace/scratch/c7749104332a/p0-tools/native/usr/lib
exec /workspace/scratch/c7749104332a/p0-tools/native/usr/bin/mono-sgen --config /workspace/scratch/c7749104332a/p0-tools/native/etc/mono/config "$@"
